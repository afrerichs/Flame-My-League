OopsRateLimiter
===============

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher.Handlers.RateLimit.OopsRateLimiter
    :members:
    :undoc-members:
