.. toctree::
   :maxdepth: 1

   LeagueOfLegends/index.rst
   LegendsOfRuneterra/index.rst
   Riot/index.rst
   TeamFightTactics/index.rst
   Valorant/index.rst
   