BasicRateLimiter
================

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher.Handlers.RateLimit.BasicRateLimiter
    :members:
    :undoc-members:
