from .LorEndpoint import LorEndpoint


class RankedApiUrls:
    leaderboards = LorEndpoint("/ranked/v1/leaderboards")
