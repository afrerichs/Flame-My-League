AccountApi
==========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.riot.AccountApi
    :members:
    :undoc-members:
