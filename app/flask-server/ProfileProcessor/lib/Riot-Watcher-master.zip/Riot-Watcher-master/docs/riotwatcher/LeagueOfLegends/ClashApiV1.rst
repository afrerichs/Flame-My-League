ClashApiV1
==========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.ClashApiV1
    :members:
    :undoc-members:
