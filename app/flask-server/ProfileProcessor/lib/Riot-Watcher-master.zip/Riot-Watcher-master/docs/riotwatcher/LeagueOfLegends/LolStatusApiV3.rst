LolStatusApiV3
==============

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.LolStatusApiV3
    :members:
    :undoc-members:
