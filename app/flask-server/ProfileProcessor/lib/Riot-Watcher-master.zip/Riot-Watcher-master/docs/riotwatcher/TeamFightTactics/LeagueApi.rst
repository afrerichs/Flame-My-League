LeagueApi
=========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.team_fight_tactics.LeagueApi
    :members:
    :undoc-members:
