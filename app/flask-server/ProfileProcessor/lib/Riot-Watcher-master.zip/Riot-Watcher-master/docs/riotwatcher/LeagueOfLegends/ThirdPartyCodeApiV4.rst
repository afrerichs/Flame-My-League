ThirdPartyCodeApiV4
===================

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.ThirdPartyCodeApiV4
    :members:
    :undoc-members:
