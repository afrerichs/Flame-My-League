Legends Of Runeterra Watcher
============================

.. py:currentmodule:: riotwatcher

.. autoclass:: LorWatcher
    :noindex:
    :members:
    :undoc-members:

All APIs
--------

.. toctree::
    :maxdepth: 1

    MatchApi.rst
    RankedApi.rst
