SpectatorApiV4
==============

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.SpectatorApiV4
    :members:
    :undoc-members:
