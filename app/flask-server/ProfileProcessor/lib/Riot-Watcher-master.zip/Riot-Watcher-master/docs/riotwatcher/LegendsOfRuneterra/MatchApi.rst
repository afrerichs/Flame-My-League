MatchApi
========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.legends_of_runeterra.MatchApi
    :members:
    :undoc-members:
