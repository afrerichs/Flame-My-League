__version__ = "3.2.2"
__author__ = "pseudonym117"
__title__ = "RiotWatcher"
