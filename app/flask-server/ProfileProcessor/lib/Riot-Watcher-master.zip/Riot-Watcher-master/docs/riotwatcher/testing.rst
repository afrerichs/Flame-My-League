Testing
=======

Unit and integration tests can be run with the following command from the RiotWatcher folder:

::

    tox
