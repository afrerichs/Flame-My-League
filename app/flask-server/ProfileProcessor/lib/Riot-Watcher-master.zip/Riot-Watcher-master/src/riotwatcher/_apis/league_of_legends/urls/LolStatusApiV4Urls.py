from .LeagueEndpoint import LeagueEndpoint


class LolStatusApiV4Urls:
    platform_data = LeagueEndpoint("/status/v4/platform-data")
