ApplicationRateLimiter
======================

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher.Handlers.RateLimit.ApplicationRateLimiter
    :members:
    :undoc-members:
    :show-inheritance:
