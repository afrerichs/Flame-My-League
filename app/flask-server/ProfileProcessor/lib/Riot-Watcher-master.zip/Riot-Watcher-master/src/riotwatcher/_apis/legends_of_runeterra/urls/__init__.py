from .MatchApiUrls import MatchApiUrls
from .RankedApiUrls import RankedApiUrls
