DataDragonApi
=============

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.DataDragonApi
    :members:
    :undoc-members:
