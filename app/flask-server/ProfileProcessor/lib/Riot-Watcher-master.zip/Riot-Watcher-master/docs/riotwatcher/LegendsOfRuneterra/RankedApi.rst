RankedApi
=========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.legends_of_runeterra.RankedApi
    :members:
    :undoc-members:
