.. _rate-limiter:

riotwatcher\.Handlers\.RateLimit package
========================================

.. toctree::
    :caption: Classes

    BasicRateLimiter.rst
    ApplicationRateLimiter.rst
    HeaderBasedLimiter.rst
    Limits.rst
    MethodRateLimiter.rst
    OopsRateLimiter.rst
