ChampionMasteryApiV4
====================

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.ChampionMasteryApiV4
    :members:
    :undoc-members:
