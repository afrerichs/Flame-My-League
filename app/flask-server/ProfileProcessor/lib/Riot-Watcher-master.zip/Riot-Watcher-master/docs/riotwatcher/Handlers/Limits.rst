Limits
======

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher.Handlers.RateLimit.LimitCollection
    :members:
    :undoc-members:

.. autoclass:: riotwatcher.Handlers.RateLimit.Limit
    :members:
    :undoc-members:
