from .LeagueApiUrls import LeagueApiUrls
from .MatchApiUrls import MatchApiUrls
from .SummonerApiUrls import SummonerApiUrls
