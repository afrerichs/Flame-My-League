Team Fight Tactics Watcher
==========================

.. py:currentmodule:: riotwatcher

.. autoclass:: TftWatcher
    :noindex:
    :members:
    :undoc-members:

All APIs
--------

.. toctree::
   :maxdepth: 1

   LeagueApi.rst
   MatchApi.rst
   SummonerApi.rst
   