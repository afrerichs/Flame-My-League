from .AccountApiUrls import AccountApiUrls
