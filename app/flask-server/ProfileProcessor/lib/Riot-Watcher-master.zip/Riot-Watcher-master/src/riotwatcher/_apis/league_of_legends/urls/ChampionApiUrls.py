from .LeagueEndpoint import LeagueEndpoint


class ChampionApiV3Urls:
    rotations = LeagueEndpoint("/platform/v3/champion-rotations")
