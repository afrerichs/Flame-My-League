from .LeagueEndpoint import LeagueEndpoint


class LolStatusApiV3Urls:
    shard_data = LeagueEndpoint("/status/v3/shard-data")
