LeagueApiV4
===========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.LeagueApiV4
    :members:
    :undoc-members:
