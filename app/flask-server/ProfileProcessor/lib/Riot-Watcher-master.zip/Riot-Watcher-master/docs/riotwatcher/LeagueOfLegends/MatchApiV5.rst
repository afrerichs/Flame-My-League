MatchApiV5
==========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.MatchApiV5
    :members:
    :undoc-members:
