MethodRateLimiter
=================

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher.Handlers.RateLimit.MethodRateLimiter
    :members:
    :undoc-members:
    :show-inheritance:
