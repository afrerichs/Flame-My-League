ChampionApiV3
=============

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.ChampionApiV3
    :members:
    :undoc-members:
