SummonerApi
===========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.team_fight_tactics.SummonerApi
    :members:
    :undoc-members:
