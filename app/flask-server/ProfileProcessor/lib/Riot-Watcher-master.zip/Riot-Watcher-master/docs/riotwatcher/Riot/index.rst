Riot Watcher
============

.. py:currentmodule:: riotwatcher

.. autoclass:: RiotWatcher
    :noindex:
    :members:
    :undoc-members:

All APIs
--------

.. toctree::
   :maxdepth: 1

   AccountApi.rst
