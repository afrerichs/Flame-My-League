LolStatusApiV4
==============

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.league_of_legends.LolStatusApiV4
    :members:
    :undoc-members:
