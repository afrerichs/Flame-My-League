class UrlConfig:
    root_url = "https://{platform}.api.riotgames.com"
    lor_url = "https://{platform}.api.riotgames.com"
    riot_url = "https://{platform}.api.riotgames.com"
    tft_url = "https://{platform}.api.riotgames.com"
    val_url = "https://{platform}.api.riotgames.com"
