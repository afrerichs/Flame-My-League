HeaderBasedLimiter
==================

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher.Handlers.RateLimit.HeaderBasedLimiter
    :members:
    :undoc-members:
