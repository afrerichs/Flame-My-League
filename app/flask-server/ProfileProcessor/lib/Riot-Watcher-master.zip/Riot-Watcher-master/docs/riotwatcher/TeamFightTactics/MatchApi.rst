MatchApi
========

.. py:currentmodule:: riotwatcher

.. autoclass:: riotwatcher._apis.team_fight_tactics.MatchApi
    :members:
    :undoc-members:
